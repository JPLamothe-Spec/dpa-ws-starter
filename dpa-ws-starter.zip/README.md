# DPA WebSocket Starter

This is a starter WebSocket server for receiving Twilio Media Streams in real time. Designed for deployment on Render.
